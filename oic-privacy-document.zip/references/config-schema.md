# Config schema

`build_privacy_docx.js` takes one JSON file. Relative paths inside it resolve
against the config file's own directory.

| Key | Type | Required | Purpose |
|---|---|---|---|
| `project_code` | string | yes | Appears in the subtitle and the running header |
| `version` | string | yes | Integration version, e.g. `01.00.0003` |
| `document_title` | string | no | Defaults to `Data Privacy Document` |
| `subtitle` | string | no | Rule line under the title |
| `assessment_date` | string | no | Used in the default subtitle |
| `details` | array of `[label, value]` | yes | Section 1 |
| `endpoints` | array of 5-element rows | yes | Section 2 — role, system, connection, security, endpoint |
| `delivery` | array of `[label, value]` | yes | Section 3 |
| `diagram_png` | path | yes | Section 4 image |
| `diagram_width` / `diagram_height` | number | no | Pixels; defaults 950 × 292 |
| `inventory_csv` | path | yes | Section 5, embedded as a table |
| `inventory_intro` | array of strings | no | Paragraphs above the inventory table |
| `closing_note` | string | no | Italic line at the end |
| `output_docx` | path | yes | Where to write |

## Colour rules applied automatically

The script looks for a column named `sensitivity` and colours `High` red,
`Medium` amber, everything else grey. It looks for `classification` and
colours any value containing "personal data" red. Nothing else is coloured —
that restraint is what makes the red mean something.

## Column widths

With the standard six-column inventory (`column, datatype, forwarded_to,
classification, sensitivity, notes`) the script uses tuned weights. Any other
column count gets even columns with a triple-width last column. If you are
producing a non-standard inventory, check the render before delivering.

## Worked example

```json
{
  "project_code": "DLR_CAGE_TO_SNOW_INT",
  "version": "01.00.0003",
  "subtitle": "Fields extracted from source and sent to target  ·  23 September 2026",
  "details": [
    ["Integration name", "DLR Cage To SNOW Integration"],
    ["Project code", "DLR_CAGE_TO_SNOW_INT"],
    ["Version", "01.00.0003"],
    ["Lookup key", "INT-CAGE-SNOW"],
    ["Purpose", "Send Cage related data from Carma to ServiceNow"],
    ["Platform", "Oracle Integration Cloud Gen 3 (built on 26.01.2-EC, last updated 26.04.2-EC)"],
    ["Pattern", "App-driven orchestration, freeform"],
    ["Status", "ACTIVATED"],
    ["Archive assessed", "DLR_CAGE_TO_SNOW_INT_01_00_0003.iar"],
    ["Data persisted by the integration", "None — no file, no staging table, no object store"]
  ],
  "endpoints": [
    ["Source", "Carma (via Azure Service Bus)", "DLR_SF_ASB_CLIENT", "CUSTOM",
     "Namespace dlr-t54-entint-bus · topic sbt-cage · subscription sbts-oic-servicenow"],
    ["Target", "ServiceNow CMDB", "DLR_GSNOW_CONNECTION", "OAuth two-legged",
     "POST /api/ixhbv/carma/suite  (class u_cmdb_ci_cage)"],
    ["Target", "Carma acknowledgement", "PRESEEDED_COLLOCATED_CONN_1741", "In-platform",
     "DLR_CARMA_ACK_INT  POST /ack"],
    ["Target", "Common error handler", "DLR_COMMON_ERROR_HANDLI_CONNEC", "Basic auth",
     "DLR_COMMON_ERROR_HANDLI_INT  POST /callcommonerrorhandling"],
    ["Target", "Subscription circuit breaker", "PRESEEDED_COLLOCATED_CONN_1741", "In-platform",
     "DLR_DISABLE_ENABLE_SUBSCRPTION  POST /SubService"]
  ],
  "delivery": [
    ["Trigger type", "Event-driven. Carma publishes cage events to the Azure Service Bus topic; OIC consumes them from its own subscription."],
    ["Message exchange pattern", "Fire-and-forget (one-way inbound)"],
    ["Polling", "Every 1,000 ms · MaxPollRecords 1 · 3 concurrent jobs"],
    ["Payload format", "JSON, under the element \"content\" — structure is { metadata, payload }"],
    ["Delivery to target", "Synchronous REST POST to ServiceNow; sys_id from the response is returned to Carma as an acknowledgement"],
    ["Retry", "3 attempts, driven by RetryCount in DLR_Integration_Attributes_Lookup"],
    ["Failure handling", "Persistent 401 / 404 / 502 / 503 disables the Azure Service Bus subscription (circuit breaker). Unrecovered faults call the common error handler, which emails the distribution list."],
    ["Transport security", "HTTPS on every endpoint. Credentials held in the OIC credential store; none hardcoded in the archive."]
  ],
  "diagram_png": "flow.png",
  "inventory_csv": "DLR_CAGE_TO_SNOW_INT_column_inventory.csv",
  "inventory_intro": [
    "Every field received from the source, every field sent to each target, plus tracking variables, internal variables and lookup contents. A blank \"Forwarded to\" means the field is received but not sent onward. 43 fields are received from Carma; 6 are sent to ServiceNow.",
    "Source of the inventory: the inLineJsonMessage adapter schema sample in GetCageDetails_REQUEST.jca (no XSD of the business payload exists in the archive), plus the RequestSample / ResponseSample of each REST invoke and the inline WSDL schemas of the collocated calls."
  ],
  "closing_note": "This document is a field-level data map only. Field classifications reflect the build-time schema sample; if the live message on sbt-cage has drifted, the inventory needs re-checking against production.",
  "output_docx": "DLR_CAGE_TO_SNOW_INT_privacy_document.docx"
}
```
