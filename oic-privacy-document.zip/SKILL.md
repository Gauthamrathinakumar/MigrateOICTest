---
name: oic-privacy-document
description: "Produce the standard five-section Word data privacy document for an Oracle integration — integration details, source and target systems, delivery method, a high-level flow diagram, and the full field inventory embedded as a table. Use this whenever someone asks for a data privacy document, data privacy review, privacy doc, field mapping document, data flow document or RoPA input for an OIC .iar/.par or SOA .car/.jar/.sar archive, and whenever they ask what fields or columns an integration extracts from source and sends to target. Also use it when they ask to 'generate the document' for an integration they have just uploaded, or ask for the same format as a previous integration's privacy document. Prefer this over writing a long findings report: this deliverable is deliberately a data map, not an audit, and it is the format the governance team expects."
---

# OIC data privacy document

A fixed five-section Word deliverable that answers one question well: **what
data does this integration take from the source, and what does it send to the
target?**

The value of this skill is the constraint. Most privacy write-ups sprawl into
findings, severity ratings and RoPA tables, and a reviewer who wants to know
which columns move has to hunt for them. This document does not do that. It
puts the field inventory on the page, in a landscape table, with everything
else compressed into three short tables and one diagram.

## Relationship to the analysis skills

This skill is the **output format**. It does not tell you how to read an
archive.

If `oic-privacy-assessment` or `dlr-oic-integration-review` is also loaded on
this agent, use one of them first to extract the archive and build the field
inventory, then come back here to render the document. `dlr-oic-integration-review`
takes priority for any `DLR_*` archive.

If neither is available, the two things you must get right yourself:

- **The payload schema is usually not in an XSD.** For OIC Gen 3 cloud adapters
  the only `.xsd` files are `ICSFault.xsd` and `ICSIntegrationMetadata.xsd`,
  which are plumbing. The real contract is an XML-escaped JSON sample inside the
  `.jca`: `inLineJsonMessage` for messaging triggers, `RequestSample` /
  `ResponseSample` for REST invokes, inline WSDL schemas for collocated calls.
  Miss this and you will report zero fields on an integration moving forty.
- **Received is not forwarded.** Walk every `.xsl` and every `expr.properties`
  to find which received fields are actually read. The blank `forwarded_to`
  cells are the most useful thing in the document.

## The five sections

Do not add sections. If you have findings, correctness defects or a RoPA entry,
they belong in a separate companion file, mentioned in one line at the end.

**1 — Integration details.** Two-column table: integration name, project code,
version, lookup key, purpose, platform and version, pattern, status, archive
assessed, and what the integration persists. That last row is worth including
even when the answer is "nothing", because it shortens the reviewer's job.

**2 — Source and target systems.** One row per endpoint: role, system,
connection, security, endpoint. Include the error handler, acknowledgement and
any circuit-breaker call as targets — they receive data too, and leaving them
out is how an email hop escapes review.

**3 — Delivery method.** Two-column table: trigger type, message exchange
pattern, polling or schedule, payload format, delivery to target, retry,
failure handling, transport security. This is the section people skip when
writing these by hand and then get asked about in review.

**4 — High-level flow.** One image, coarse on purpose. Source box, integration
box with three numbered steps, target box, error path box, and a footer with
the received / sent / unused counts. Do not draw the orchestration — the
retry loop and routers are unreadable at the size this renders, and the
inventory table already carries the detail.

**5 — Field inventory.** The CSV embedded as a table, every row. Standard
columns are `column, datatype, forwarded_to, classification, sensitivity,
notes`. Prefix rows so they group when sorted: `ENVELOPE`, `PAYLOAD`,
`TRACKING`, `OUTBOUND <target>`, `INTERNAL`, `DVM`, `CONNECTION`.

## Workflow

### Step 1 — Build the inventory CSV

One row per field, columns `column, datatype, forwarded_to, classification,
sensitivity, notes`. Leave `forwarded_to` blank when the field is received and
never used, and say so in the notes.

Inventory the things that live outside the payload, because they are easy to
forget and they are usually where the personal data actually is:

- tracking variables (`trackingVariableGroup` in `project.xml`) — they persist
  in the monitoring store, typically longer than the payload
- notification and log expressions — `var_log_message` and similar splice
  payload values into email bodies
- DVM / lookup contents — routinely carry staff email addresses and file paths
  for the whole estate
- connection audit blocks in `appinstances/*.xml` — `createdBy`,
  `lastUpdatedBy`, `lockedBy` name real people

Classify honestly. In infrastructure and B2B contexts most sensitive data is
commercially confidential or physical-security relevant rather than personal,
and a document that labels floor plans "PII" gets ignored. Check the sample
value before classifying — `"modified_by": "Tracye Wilhelm"` settles a question
the field name only raises.

### Step 2 — Draw the flow

Copy `assets/flow_template.svg` from this skill's own directory, replace the
`{{PLACEHOLDER}}` tokens, then render it to PNG:

```bash
soffice --headless --convert-to png flow.svg
```

If LibreOffice is not on the runtime, fall back in this order: `rsvg-convert
-w 1400 flow.svg -o flow.png`, then `inkscape --export-type=png flow.svg`, then
Python `cairosvg`. If none are available, skip the image and render section 4
as a numbered text list of the same boxes — the document is still valid without
the picture, and it is better than shipping a broken image reference.

### Step 3 — Write the config and build

Write a config JSON following `references/config-schema.md`, then run the
renderer from this skill's own directory:

```bash
node ./scripts/build_privacy_docx.js config.json
```

The script needs the `docx` npm package. Check first with
`node -e "require('docx')"`; if that fails, `npm install docx` in the working
directory. If npm is unreachable, say so plainly and deliver the CSV plus a
Markdown version of the five sections rather than silently changing the
format. The script fixes the layout, colours and column widths so every
integration's document looks identical; everything it says comes from the config
and the CSV.

### Step 4 — Look at it

```bash
soffice --headless --convert-to pdf out.docx --outdir .
pdftoppm -jpeg -r 80 out.pdf pg
```

Then read the images. Skip this step if neither tool is present rather than
treating it as a blocker. Check the diagram is legible at that size, that no
inventory row has been split awkwardly, and that the red in the sensitivity
column is rare enough to still mean something.

### Step 5 — Deliver

Deliver the `.docx` **and** the `.csv`. Reviewers filter and sort the CSV and
drop it straight into a RoPA workbook; the Word document is what gets
circulated. Present both.

## Calibration

**The counts are the headline.** "43 fields received, 6 sent to the target, 37
received but not sent" carries more argument than any paragraph. Put that line
in the diagram footer and in the inventory intro.

**Grade honestly in the classification column.** A cage or asset GUID is not a
person. Square footage is commercially confidential, not personal. An
`account_number` in a B2B context identifies a company. Say which context you
are applying.

**Free text deserves its own label.** Fields like `alias`, `description`,
`external_reference`, `comments` and `*_text` are unconstrained, so a field
meant for a label can end up holding someone's name. Mark them as a possible
channel rather than asserting they contain personal data, and note in the CSV
where each one flows — a free-text field that is simultaneously forwarded,
tracked and emailed is exposed three times over.

**Say plainly when the archive itself contains personal data.** Exported DVMs
and connection audit blocks routinely carry staff names and email addresses for
an entire estate. People attach these files to tickets without realising. One
row in the inventory and one sentence in the notes is enough.

**State the freshness caveat in the closing note.** The JCA sample reflects the
contract at build time and is often captured against test data. If the live
message has drifted, the inventory needs re-checking against production.

## Runtime requirements

This skill was written for a Linux sandbox with Node, LibreOffice and poppler
available. On a runtime without shell or script execution, it still works as an
instruction-only skill: the five sections, the classification rules and the
calibration guidance all apply, and the deliverable becomes the CSV plus
Markdown instead of a rendered `.docx`. Do not drop or reorder the sections to
compensate.

All paths in this file are relative to the skill's own directory. Do not assume
any sibling skill's files are on disk.

## Bundled resources

- `scripts/build_privacy_docx.js` — the renderer; takes one config JSON
- `assets/flow_template.svg` — the high-level diagram, with placeholders
- `references/config-schema.md` — config keys and a full worked example
