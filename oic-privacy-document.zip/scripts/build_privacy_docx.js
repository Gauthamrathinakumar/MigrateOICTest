#!/usr/bin/env node
/*
 * build_privacy_docx.js — renders the five-section OIC data privacy document.
 *
 *   node build_privacy_docx.js config.json
 *
 * Everything the document says comes from the config file and the CSV it points
 * at. The layout, colours, table widths and section order are fixed here on
 * purpose: the point of the skill is that every integration's document looks
 * the same, so a reviewer who has read one can read any of them.
 *
 * See references/config-schema.md for the config shape.
 */
const fs = require('fs');
const path = require('path');
const {
  Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType,
  Table, TableRow, TableCell, WidthType, ShadingType, BorderStyle,
  PageOrientation, Header, Footer, PageNumber, ImageRun
} = require('docx');

// ---------------------------------------------------------------- config
const cfgPath = process.argv[2];
if (!cfgPath) {
  console.error('usage: node build_privacy_docx.js <config.json>');
  process.exit(1);
}
const cfg = JSON.parse(fs.readFileSync(cfgPath, 'utf8'));
const base = path.dirname(path.resolve(cfgPath));
const resolve = p => (p && !path.isAbsolute(p) ? path.join(base, p) : p);

// ---------------------------------------------------------------- layout
// Letter landscape: pass portrait dimensions, docx-js swaps them.
const PORT_W = 12240, PORT_H = 15840, MARGIN = 720;
const TABLE_W = PORT_H - 2 * MARGIN; // 14400 dxa of usable width

const NAVY = '1D2733', GREY = '5B6773', RED = 'B4402C', AMBER = 'B07A1E';
const HDR_BG = 'E3E9EF', ALT_BG = 'F6F8FA', RULE = '5B8FBF';

const t = (text, o = {}) => new TextRun({ text, size: 20, color: NAVY, ...o });

const p = (text, o = {}) => new Paragraph({
  spacing: o.spacing || { after: 120 },
  children: [new TextRun({
    text, size: o.size || 20, bold: o.bold,
    color: o.color || NAVY, italics: o.italics,
  })],
});

const h1 = text => new Paragraph({
  heading: HeadingLevel.HEADING_1,
  spacing: { before: 340, after: 150 },
  children: [new TextRun({ text, color: NAVY })],
});

function cell(text, { width, bold = false, bg, color = NAVY, size = 16 } = {}) {
  return new TableCell({
    width: { size: width, type: WidthType.DXA },
    shading: bg ? { type: ShadingType.CLEAR, fill: bg, color: 'auto' } : undefined,
    margins: { top: 50, bottom: 50, left: 90, right: 90 },
    children: [new Paragraph({
      spacing: { after: 0 },
      children: [new TextRun({ text: String(text == null ? '' : text), bold, color, size })],
    })],
  });
}

function table(widths, header, rows, opts = {}) {
  const trs = [];
  if (header) {
    trs.push(new TableRow({
      tableHeader: true, cantSplit: true,
      children: header.map((hd, i) =>
        cell(hd, { width: widths[i], bold: true, bg: HDR_BG, size: opts.size || 16 })),
    }));
  }
  rows.forEach((r, ri) => {
    trs.push(new TableRow({
      cantSplit: true,
      children: widths.map((w, i) => cell(r[i], {
        width: w,
        bg: ri % 2 === 1 ? ALT_BG : undefined,
        bold: opts.boldCol === i,
        color: opts.colorRules && opts.colorRules[i] ? opts.colorRules[i](r[i]) : NAVY,
        size: opts.size || 16,
      })),
    }));
  });
  return new Table({
    columnWidths: widths,
    width: { size: widths.reduce((a, b) => a + b, 0), type: WidthType.DXA },
    borders: {
      top: { style: BorderStyle.SINGLE, size: 2, color: 'C4CDD6' },
      bottom: { style: BorderStyle.SINGLE, size: 2, color: 'C4CDD6' },
      left: { style: BorderStyle.SINGLE, size: 2, color: 'C4CDD6' },
      right: { style: BorderStyle.SINGLE, size: 2, color: 'C4CDD6' },
      insideHorizontal: { style: BorderStyle.SINGLE, size: 2, color: 'D6DDE4' },
      insideVertical: { style: BorderStyle.SINGLE, size: 2, color: 'D6DDE4' },
    },
    rows: trs,
  });
}

// Proportionally scale a set of relative column weights to the usable width.
const widths = weights => {
  const total = weights.reduce((a, b) => a + b, 0);
  const out = weights.map(w => Math.round((w / total) * TABLE_W));
  out[out.length - 1] += TABLE_W - out.reduce((a, b) => a + b, 0);
  return out;
};

// ---------------------------------------------------------------- CSV
function parseCSV(txt) {
  const rows = [];
  let row = [], field = '', quoted = false;
  for (let i = 0; i < txt.length; i++) {
    const c = txt[i];
    if (quoted) {
      if (c === '"') {
        if (txt[i + 1] === '"') { field += '"'; i++; } else quoted = false;
      } else field += c;
    } else if (c === '"') quoted = true;
    else if (c === ',') { row.push(field); field = ''; }
    else if (c === '\n') { row.push(field); rows.push(row); row = []; field = ''; }
    else if (c !== '\r') field += c;
  }
  if (field !== '' || row.length) { row.push(field); rows.push(row); }
  return rows.filter(r => r.some(x => x !== ''));
}

const csv = parseCSV(fs.readFileSync(resolve(cfg.inventory_csv), 'utf8'));
const csvHeader = csv[0].map(x =>
  x.replace(/_/g, ' ').replace(/^\w/, m => m.toUpperCase()));
const csvRows = csv.slice(1);

// Column weights for the inventory. Six columns is the standard shape
// (column / datatype / forwarded to / classification / sensitivity / notes);
// anything else gets even columns with a wider last one for notes.
const invWeights = csvHeader.length === 6
  ? [270, 125, 265, 215, 95, 470]
  : csvHeader.map((_, i) => (i === csvHeader.length - 1 ? 3 : 1));

const sensIdx = csvHeader.findIndex(x => /sensitivity/i.test(x));
const classIdx = csvHeader.findIndex(x => /classification/i.test(x));
const invColors = {};
if (sensIdx >= 0) {
  invColors[sensIdx] = v =>
    /^high$/i.test(v) ? RED : /^medium$/i.test(v) ? AMBER : GREY;
}
if (classIdx >= 0) {
  // Only rows that *are* personal data go red. "Free text — may embed personal
  // data" is a flag, not a finding, and colouring it too spends the reader's
  // attention on maybes.
  invColors[classIdx] = v => /^personal data/i.test(String(v).trim()) ? RED : NAVY;
}

// ---------------------------------------------------------------- document
const children = [];

// Title block
children.push(new Paragraph({
  spacing: { after: 60 },
  children: [t(cfg.document_title || 'Data Privacy Document', { size: 40, bold: true })],
}));
children.push(new Paragraph({
  spacing: { after: 40 },
  children: [t(`${cfg.project_code}  ·  version ${cfg.version}`, { size: 24, color: GREY })],
}));
children.push(new Paragraph({
  border: { bottom: { style: BorderStyle.SINGLE, size: 8, color: RULE } },
  spacing: { after: 200 },
  children: [t(cfg.subtitle
    || `Fields extracted from source and sent to target  ·  ${cfg.assessment_date || ''}`,
    { size: 19, color: GREY })],
}));

// 1 — Integration details
children.push(h1('1.  Integration details'));
children.push(table(widths([21, 79]), null, cfg.details, { boldCol: 0, size: 18 }));

// 2 — Source and target systems
children.push(h1('2.  Source and target systems'));
children.push(table(
  widths([10, 17, 22, 14, 37]),
  ['Role', 'System', 'Connection', 'Security', 'Endpoint'],
  cfg.endpoints,
  { size: 17 }
));

// 3 — Delivery method
children.push(h1('3.  Delivery method'));
children.push(table(widths([22, 78]), null, cfg.delivery, { boldCol: 0, size: 18 }));

// 4 — High-level flow
children.push(h1('4.  High-level flow'));
if (cfg.diagram_png && fs.existsSync(resolve(cfg.diagram_png))) {
  const img = fs.readFileSync(resolve(cfg.diagram_png));
  children.push(new Paragraph({
    spacing: { after: 160 },
    children: [new ImageRun({
      data: img, type: 'png',
      transformation: {
        width: cfg.diagram_width || 950,
        height: cfg.diagram_height || 292,
      },
    })],
  }));
} else {
  children.push(p('[diagram missing — render the flow SVG to PNG and rerun]',
    { color: RED, italics: true }));
}

// 5 — Field inventory
children.push(h1('5.  Field inventory — source to target'));
(cfg.inventory_intro || []).forEach((line, i) =>
  children.push(p(line, {
    size: i === 0 ? 18 : 17,
    color: GREY,
    spacing: { after: i === (cfg.inventory_intro.length - 1) ? 200 : 120 },
  })));
children.push(table(widths(invWeights), csvHeader, csvRows, {
  size: 15, colorRules: invColors,
}));

if (cfg.closing_note) {
  children.push(new Paragraph({
    spacing: { before: 320 },
    children: [t(cfg.closing_note, { size: 17, italics: true, color: GREY })],
  }));
}

// ---------------------------------------------------------------- assemble
const runningHead = `${cfg.project_code} ${cfg.version}  —  ${cfg.document_title || 'Data Privacy Document'}`;

const doc = new Document({
  styles: {
    default: {
      document: { run: { font: 'Calibri', size: 20, color: NAVY } },
      heading1: { run: { font: 'Calibri', size: 28, bold: true, color: NAVY } },
    },
  },
  sections: [{
    properties: {
      page: {
        size: { width: PORT_W, height: PORT_H, orientation: PageOrientation.LANDSCAPE },
        margin: { top: MARGIN, bottom: MARGIN, left: MARGIN, right: MARGIN },
      },
    },
    headers: {
      default: new Header({
        children: [new Paragraph({
          alignment: AlignmentType.RIGHT,
          children: [t(runningHead, { size: 16, color: '8C98A4' })],
        })],
      }),
    },
    footers: {
      default: new Footer({
        children: [new Paragraph({
          alignment: AlignmentType.CENTER,
          children: [
            t('Page ', { size: 16, color: '8C98A4' }),
            new TextRun({ children: [PageNumber.CURRENT], size: 16, color: '8C98A4' }),
            t(' of ', { size: 16, color: '8C98A4' }),
            new TextRun({ children: [PageNumber.TOTAL_PAGES], size: 16, color: '8C98A4' }),
          ],
        })],
      }),
    },
    children,
  }],
});

const out = resolve(cfg.output_docx);
Packer.toBuffer(doc).then(b => {
  fs.mkdirSync(path.dirname(out), { recursive: true });
  fs.writeFileSync(out, b);
  console.log(`wrote ${out}  (${b.length} bytes, ${csvRows.length} inventory rows)`);
});
